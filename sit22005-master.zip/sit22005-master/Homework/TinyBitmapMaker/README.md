# TinyBMP Maker
TinyBMP Maker program is design to manipulate BMP file. 

## Problem Description
In this problem, you will implement a program that manipulating a BMP file, such as Photoshop.

## Background
Before implementing the TinybmpMaker, you should understand several things. 

### BMP file format

### Image Filter

### Low-pass Filter

### High-pass Filter

### Image Filp