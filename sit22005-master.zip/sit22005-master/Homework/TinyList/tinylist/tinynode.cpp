//
// Created by Changbeom Choi on 2017. 5. 9..
//

#include "tinynode.h"

tinynode::tinynode()
:m_pNext(NULL)
{

}


