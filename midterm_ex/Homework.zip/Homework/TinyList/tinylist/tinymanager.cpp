//
// Created by Changbeom Choi on 2017. 5. 9..
//

#include "tinymanager.h"

tinymanager::tinymanager()
:m_pHead(NULL)
{

}

tinymanager::~tinymanager()
{

}