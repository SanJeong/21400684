//
// Created by Changbeom Choi on 2017. 5. 9..
//

#ifndef SIT22005_TINYLIST_DEF_H
#define SIT22005_TINYLIST_DEF_H

#ifndef NULL
#define NULL (0)
#endif

#endif //SIT22005_TINYLIST_DEF_H
