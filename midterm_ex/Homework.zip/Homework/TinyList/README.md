# Tiny List
TinyList problem is to practice how to implement a data structure. 
The linked list structure is a linear collection of elements. 
The linked list structure links multiple nodes to manage memory storage dynamically.
Which means, the memory storage of the linked list structure may grow at run time.  

## Problem Description
In this problem you will implement a linked list. 
Especially, you will practice how to allocate node and deallocate the node during runtime.

### Create List Operation

### Insert Operation

### Delete Operation

### Search Operation

